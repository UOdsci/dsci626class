learn_stats <- function(love=TRUE){
  if(love==TRUE){
    print("I love learning about statistics!")
  }
  else {
    print("I still should accept that statistics is an awesome field.")
  }
}